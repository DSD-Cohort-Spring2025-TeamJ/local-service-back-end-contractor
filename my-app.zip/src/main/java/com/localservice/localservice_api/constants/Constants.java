package com.localservice.localservice_api.constants;

public enum Constants {
    PENDING,
    ASSIGNED,
    COMPLETED,
    REJECTED,
    ACTIVE,
    ACCEPTED
}
