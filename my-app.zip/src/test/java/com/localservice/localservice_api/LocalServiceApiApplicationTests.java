package com.localservice.localservice_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LocalServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
